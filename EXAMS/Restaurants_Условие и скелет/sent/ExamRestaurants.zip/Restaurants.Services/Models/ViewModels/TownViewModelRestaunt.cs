﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restaurants.Services.Models.ViewModels
{
    public class TownViewModelRestaunt
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}